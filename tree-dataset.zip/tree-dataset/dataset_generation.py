import os
from keras.preprocessing.image import ImageDataGenerator
import keras

target_size = (256, 256)
in_positives_dir = "positives"
in_negatives_dir = "negatives"
out_positives_dir = "dataset_preprocessed/positives"
out_negatives_dir = "dataset_preprocessed/negatives"
positives_list_file = "positives.txt"
negatives_list_file = "negatives.txt"

def generate_from_directory(src_directory, dst_directory):
    """
        Perform data augmentation on the images stored inside src_directory and 
        store the augmented data inside dst_directory
    """
    datagen = ImageDataGenerator( 
            rotation_range = 20, 
            shear_range = 0.3, 
            zoom_range = 0.3, 
            horizontal_flip = True, 
            brightness_range = (0.5, 2.0)) 

    global target_size

    dataset = datagen.flow_from_directory(
        directory=src_directory,
        target_size=target_size,
        color_mode="rgb",
        classes=None,
        class_mode="categorical",
        batch_size=16,
        shuffle=True,
        seed=None,
        save_to_dir=dst_directory,
        save_prefix="",
        save_format="png",
        follow_links=False,
        subset=None,
        interpolation="bilinear",
    )

    i=0
    for batch in dataset:
        i += 1
        if i > 32: 
            break

# Perform data augmentation on positive and negative samples
print("generating positive images")
generate_from_directory(in_positives_dir, out_positives_dir)
print("generating negative images")
generate_from_directory(in_negatives_dir, out_negatives_dir)

# Generate file containing list of positive samples
print("searching positive images")
filenames = os.listdir(out_positives_dir)
f = open(positives_list_file, "w")

count = 0
for filename in filenames:
    if filename.endswith('.jpg') or filename.endswith('.png'):
        path = f"{out_positives_dir}/{filename}"
        f.write(f"{path} 1 0 0 {target_size[0]} {target_size[1]}\n")
        count += 1
print(f"found {count} positives")

f.close()

# Generate file containing list of negative samples
print("searching negative images")
filenames = os.listdir(out_negatives_dir)
f = open(negatives_list_file, "w")

count = 0
for filename in filenames:
    if filename.endswith('.jpg') or filename.endswith('.png'):
        path = f"{out_negatives_dir}/{filename}"
        f.write(f"{path}\n")
        count += 1
print(f"found {count} negatives")

f.close()